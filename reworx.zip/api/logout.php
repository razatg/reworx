<?php 
include_once('../config-ini.php');
session_destroy();
exit;
?>
